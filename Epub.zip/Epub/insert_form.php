<!DOCTYPE HTML>
<html>
<head>
<style>
.error {color: #FF0000;}
    h2 {text-align: center;}
    p {text-align: center;}
    div {text-align: center;}
    form {text-align: center;}
</style>
</head>
<body>

<?php
require "DataBase.php";
$db = new DataBase();

    if(isset($_POST['submit'])){


      $title=$_POST['title'];
      $author=$_POST['author'];
         $file_name=$_FILES['image']['name'];
         $file_path=$_FILES['image']['tmp_name'];
      $dest_file='uploads/'.$file_name;
  move_uploaded_file($file_path, $dest_file);
      $summary=$_POST['summary'];
       $year=$_POST['year'];
         $publisher=$_POST['publisher'];
           $narrator=$_POST['narrator'];
             $category=$_POST['category'];

              $epub_name=$_FILES['epub']['name'];
              $epub_path=$_FILES['epub']['tmp_name'];
      $epub_file='uploads/'.$epub_name;
  move_uploaded_file($epub_path, $epub_file);

      $audio_name=$_FILES['audio']['name'];
       $audio_path=$_FILES['audio']['tmp_name'];
      $audio_file='uploads/'.$audio_name;
  move_uploaded_file($audio_path, $audio_file);

if ($db->dbConnect()){

             if ($db->insertForm("books", $title, $author, $dest_file, $summary,$year,$publisher,$narrator,$category,$epub_file,$audio_file)){
              echo "inserted";

             } else{
              echo "not inserted";
             }

       }else echo "Error: Database connection";





    }
    
 


?>

<h2>Insert New Epub files</h2>
<form method="POST" action="" enctype="multipart/form-data">
  Book title: <input type="text" name="title">
  <br><br>
  Book author: <input type="text" name="author">
  <br><br>
  Book cover image:  <input type="file"  name="image" accept="image/*">
  <br><br>
  Book summary: <textarea name="summary" rows="5" cols="40"></textarea>
  <br><br>
   Published year: <input type="text" name="year">
  <br><br>
   Publisher: <input type="text" name="publisher">
   <br><br>
   Narrator: <input type="text" name="narrator">
   <br><br>
   Category: <input type="text" name="category">
    <br><br>
   Epub file: <input type="file" name="epub">
    <br><br>
   Audio file: <input type="file" name="audio">
   <br><br>
   <br><br>
  <br><br>  <input type="submit" name="submit" value="Submit">
</form>



</body>
</html>
