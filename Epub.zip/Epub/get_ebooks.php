<?php
require "DataBase.php";
$db = new DataBase();
    if ($db->dbConnect()) {

    	$db->getEbooks("books");

    

		
       
    } else echo "Error: Database connection";
?>
